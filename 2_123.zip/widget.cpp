#include "widget.h"
#include "ui_widget.h"
#include "QString"
#include"QDebug"
#include"QMessageBox"
#include"iostream"
#include<bits/stdc++.h>
using namespace std;


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_start_clicked()
{

    QString way=ui->dk_way->currentText();
    QString house_price=ui->house_price->toPlainText();
    QString house_area=ui->house_area->toPlainText();
    QString ajcs=ui->ajcs->toPlainText();
    QString dk_ll=ui->dk_ll->toPlainText();
    QString dk_year=ui->df_year->toPlainText();
    QString gjj=ui->gongjijin_dke->toPlainText();
    QString gjj_ll=ui->gjj_ll->toPlainText();
    QString sd_price=ui->sd_price->toPlainText();
    QString sd_ll=ui->sd_ll->toPlainText();
    if(way=="商业贷款")
    {
        QString chy1=ui->way1->currentText();
        if(chy1=="按面积平方和计算")
        {
            double price,area,ajcs,dk_ll;
            int year;
            price=ui->house_price->toPlainText().toDouble();
            area=ui->house_area->toPlainText().toDouble();
            ajcs=ui->ajcs->toPlainText().toDouble()/10;
            dk_ll=ui->dk_ll->toPlainText().toDouble()/100;
            year=ui->df_year->toPlainText().toInt();
            QString chy2=ui->pay_way->currentText();
            int flag=1;
            if(price<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "房子单价怎么变成负数了？商家倒贴钱给你吗\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->house_price->setText("0");

                if(btn==QMessageBox::No)
                    ui->output->append("房子单价怎么变成负数了？商家倒贴钱给你吗？");

            }

            if(area<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "房子有占地面积的奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->house_area->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("房子有占地面积的奥");

            }

            if(ajcs*10>7)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "首付至少3成，别太贪心了\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->ajcs->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("首付至少3成，别太贪心了");

            }
            if(dk_ll<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款利率出问题了，自己看下\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->dk_ll->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("贷款利率出问题了，自己看下");

            }
            if(year<=0)
            {
                flag=0;
            QMessageBox::StandardButton btn;
            btn=QMessageBox::question(this, "警告", "还款年数出问题了奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
            if(btn==QMessageBox::Yes)
             ui->ajcs->setText("0");

             if(btn==QMessageBox::No)

             ui->output->append("还款年数出问题了奥");

            }


            if(flag)
            {

            if(chy2=="等额本息")
            {
                ui->output->append("你所选的方式是商业贷款，按面积平方和，等额本息");
                ui->output->append("你需要首付：（元）  "+QString::number(price*area*(1-ajcs),'f',0));
                ui->output->append("每月月供：（元）    "+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))/12));
                ui->output->append("贷款总额为 （元）   "+QString::number(price*area*ajcs,'f',0));
                ui->output->append("你每年需要还款:（元）"+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1)),'f',0));
                ui->output->append("总还款:(元）       "+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))*year,'f',1));
                ui->output->append("\n");
            }
            if(chy2=="等额本金")
            {
                ui->output->append("你所选的方式是商业贷款，按面积平方和，等额本金");
                ui->output->append("贷款总额为（元）    "+QString::number(price*area*ajcs,'f',0));
                ui->output->append("你每年需要还款（元） "+QString::number(price*area*ajcs/year,'f',0));
                ui->output->append("以及还需要剩下贷款乘年利率的钱，无法直接展示，就这样告诉你了\n");
            }

        }
        }

        if(chy1=="按贷款总额计算")
        {
            double p,ajcs,dk_ll;
            int year;
            p=ui->whole_price->toPlainText().toDouble();
            ajcs=ui->ajcs->toPlainText().toDouble()/10;
            dk_ll=ui->dk_ll->toPlainText().toDouble()/100;
            year=ui->df_year->toPlainText().toInt();
            ui->output->append("贷款总额为 "+QString::number(p,'f',0));
            QString chy3=ui->pay_way->currentText();
            int flag=1;
            if(p<0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款总额不能小于0哦\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
                if(btn==QMessageBox::Yes)
                 ui->whole_price->setText("0");

                 if(btn==QMessageBox::No)

                 ui->output->append("贷款总额不能小于0哦");
            }

            if(ajcs*10>7)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "首付至少3成，别太贪心了\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->ajcs->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("首付至少3成，别太贪心了");

            }

            if(dk_ll<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款利率出问题了，自己看下\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->dk_ll->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("贷款利率出问题了，自己看下");

            }

            if(year<=0)
            {
                flag=0;
            QMessageBox::StandardButton btn;
            btn=QMessageBox::question(this, "警告", "还款年数出问题了奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
            if(btn==QMessageBox::Yes)
             ui->df_year->setText("0");

             if(btn==QMessageBox::No)

             ui->output->append("还款年数出问题了奥");

            }

            if(flag)
            {


            if(chy3=="等额本息")
            {
                ui->output->append("你所选的方式是商业贷款，按贷款总额算，等额本息");
                ui->output->append("你需要首付：（元）      "+QString::number(p*(1-ajcs),'f',0));
                ui->output->append("每月月供：（元）        "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))/12,'f',0));
                ui->output->append("贷款总额为 （元）       "+QString::number(p*ajcs,'f',0));
                ui->output->append("你每年需要还款：（元）   "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1)),'f',0));
                ui->output->append("总还款:(元）           "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))*year,'f',1));
                ui->output->append("\n");
            }
            if(chy3=="等额本金")
            {
                ui->output->append("你所选的方式是商业贷款，按贷款总额算，等额本金");
                ui->output->append("你每年需要还款 （元）"+QString::number(p*(1-ajcs)/year,'f',0));
                ui->output->append("每月递减");
                ui->output->append("还需要剩下贷款乘年利率的钱，无法直接展示，就这样告诉你了哈哈哈\n");
            }
            }

        }
    }

    if(way=="公积金贷款")
    {
        QString chy1=ui->way1->currentText();
        if(chy1=="按面积平方和计算")
        {
            double price,area,ajcs,dk_ll;
            int year;
            price=ui->house_price->toPlainText().toDouble();
            area=ui->house_area->toPlainText().toDouble();
            ajcs=ui->ajcs->toPlainText().toDouble()/10;
            dk_ll=ui->dk_ll->toPlainText().toDouble()/100;
            year=ui->df_year->toPlainText().toInt();
            QString chy2=ui->pay_way->currentText();
            int flag=1;
            if(price<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "房子单价怎么变成负数了？商家倒贴钱给你吗\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->house_price->setText("0");

                if(btn==QMessageBox::No)
                    ui->output->append("房子单价怎么变成负数了？商家倒贴钱给你吗？");

            }

            if(area<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "房子有占地面积的奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->house_area->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("房子有占地面积的奥");

            }

            if(ajcs*10>7)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "首付至少3成，别太贪心了\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->ajcs->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("首付至少3成，别太贪心了");

            }

            if(dk_ll<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款利率出问题了，自己看下\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->dk_ll->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("贷款利率出问题了，自己看下");

            }
            if(year<=0)
            {
                flag=0;
            QMessageBox::StandardButton btn;
            btn=QMessageBox::question(this, "警告", "还款年数出问题了奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
            if(btn==QMessageBox::Yes)
             ui->ajcs->setText("0");

             if(btn==QMessageBox::No)

             ui->output->append("还款年数出问题了奥");

            }
            if(flag)
            {

            if(chy2=="等额本息")
            {
                ui->output->append("你所选的方式是公积金贷款，按面积平方和，等额本息");
                ui->output->append("你需要首付：（元）      "+QString::number(price*area*(1-ajcs),'f',0));
                ui->output->append("每月月供：（元）        "+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))/12));
                ui->output->append("贷款总额为 （元）       "+QString::number(price*area*ajcs,'f',0));
                ui->output->append("你每年需要还款：（元）   "+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1)),'f',0));
                ui->output->append("总还款:(元）           "+QString::number(price*area*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))*year,'f',1));
                ui->output->append("\n");
            }
            if(chy2=="等额本金")
            {
                ui->output->append("你所选的方式是公积金贷款，按面积平方和，等额本金");
                ui->output->append("贷款总额为    （元）"+QString::number(price*area*ajcs,'f',0));
                ui->output->append("你每年需要还款 （元） "+QString::number(price*area*ajcs/year,'f',0));
                ui->output->append("以及还需要剩下贷款乘年利率的钱，无法直接展示，就这样告诉你了\n");
            }
            }
        }



        if(chy1=="按贷款总额计算")
        {
            double p,ajcs,dk_ll;
            int year;
            p=ui->whole_price->toPlainText().toDouble();
            ajcs=ui->ajcs->toPlainText().toDouble()/10;
            dk_ll=ui->dk_ll->toPlainText().toDouble()/100;
            year=ui->df_year->toPlainText().toInt();
            ui->output->append("贷款总额为 "+QString::number(p,'f',0));
            QString chy3=ui->pay_way->currentText();
            int flag=1;
            if(p<0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款总额不能小于0哦\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
                if(btn==QMessageBox::Yes)
                 ui->whole_price->setText("0");

                 if(btn==QMessageBox::No)

                 ui->output->append("贷款总额不能小于0哦");
            }

            if(ajcs*10>7)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "首付至少3成，别太贪心了\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->ajcs->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("首付至少3成，别太贪心了");

            }

            if(dk_ll<=0)
            {
                flag=0;
                QMessageBox::StandardButton btn;
                btn=QMessageBox::question(this, "警告", "贷款利率出问题了，自己看下\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);

                if(btn==QMessageBox::Yes)
                    ui->dk_ll->setText("0");

                if(btn==QMessageBox::No)

                ui->output->append("贷款利率出问题了，自己看下");

            }

            if(year<=0)
            {
                flag=0;
            QMessageBox::StandardButton btn;
            btn=QMessageBox::question(this, "警告", "还款年数出问题了奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
            if(btn==QMessageBox::Yes)
             ui->df_year->setText("0");

             if(btn==QMessageBox::No)

             ui->output->append("还款年数出问题了奥");

            }
            if(flag)
            {



            if(chy3=="等额本息")
            {
                ui->output->append("你所选的方式是公积金贷款，按贷款总额算，等额本息");
                ui->output->append("你需要首付：（元）      "+QString::number(p*(1-ajcs),'f',0));
                ui->output->append("每月月供：（元）        "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))/12,'f',4));
                ui->output->append("贷款总额为 （元）       "+QString::number(p*ajcs,'f',2));
                ui->output->append("你每年需要还款：（元）   "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1)),'f',2));
                ui->output->append("总还款:(元）           "+QString::number(p*ajcs*dk_ll*(pow(1+dk_ll,year)/(pow(1+dk_ll,year)-1))*year,'f',1));
                ui->output->append("\n");
            }
            if(chy3=="等额本金")
            {
                ui->output->append("你所选的方式是公积金贷款，按贷款总额算，等额本金");
                ui->output->append("你每年需要还款（元） "+QString::number(p*(1-ajcs)/year,'f',0));
                ui->output->append("每月递减");
                ui->output->append("还需要剩下贷款乘年利率的钱，无法直接展示，就这样告诉你了哈哈哈\n");
            }
            }

        }

}




    if(way=="组合贷款")
    {
         double sd,sdll,gjj,gjjll,ajcs;
         int year;
         ajcs=ui->ajcs_->toPlainText().toDouble()/10;
         year=ui->df_year->toPlainText().toInt();
         sd=ui->sd_price->toPlainText().toDouble();
         sdll=ui->sdll->toPlainText().toDouble()/100;
         gjj=ui->gongjijin_dke->toPlainText().toDouble();
         gjjll=ui->gjj_ll->toPlainText().toDouble()/100;
         QString chy4=ui->pay_way->currentText();
         double x;
         x=sd*ajcs*sdll*(pow(1+sdll,year)/(pow(1+sdll,year)-1))+gjj*ajcs*gjjll*(pow(1+gjjll,year)/(pow(1+gjjll,year)-1));
         int flag=1;
         if(year<=0)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "还款年数出问题了奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->df_year->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("还款年数出问题了奥");

         }

         if(ajcs*10>7)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "首付至少3成奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->ajcs_->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("首付至少3成奥");

          }

         if(sd<=0)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "商贷不能为负数奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->sd_price->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("商贷不能为负数奥");

          }

         if(sdll<=0)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "商贷利率不能为负数奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->sdll->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("商贷利率不能为负数奥");

          }

         if(gjj<=0)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "公积金贷款额不能为负数奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->gongjijin_dke->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("公积金贷款额不能为负数奥");

          }

         if(gjjll<=0)
         {
          flag=0;
         QMessageBox::StandardButton btn;
         btn=QMessageBox::question(this, "警告", "公积金利率不能为负数奥\n是否重新输入？", QMessageBox::Yes|QMessageBox::No);
         if(btn==QMessageBox::Yes)
          ui->gjj_ll->setText("0");

          if(btn==QMessageBox::No)

          ui->output->append("公积金利率不能为负数奥");

          }

         if(flag)
         {





         if(chy4=="等额本息")
         {
             ui->output->append("你所选的方式是组合贷款，等额本息");
             ui->output->append("每月月供：（元）        "+QString::number(x,'f',0));
             ui->output->append("贷款总额为 （元）       "+QString::number((sd+gjj)*ajcs,'f',0));
             ui->output->append("你每年需要还款：（元）   "+QString::number(x*12,'f',0));
             ui->output->append("总还款:(元）           "+QString::number(x*year,'f',0));
             ui->output->append("\n");
         }
         if(chy4=="等额本金")
         {
             ui->output->append("你所选的方式是组合贷款，等额本金");
             ui->output->append("你每年需要还款（元） "+QString::number((sd+gjj)*(1-ajcs)/year,'f',0));
             ui->output->append("每月递减");
             ui->output->append("还需要剩下贷款乘年利率的钱，无法直接展示，就这样告诉你了哈哈哈\n");
         }
    }
    }


    }
void Widget::on_remake_clicked()
{
    QMessageBox::StandardButton btn;
    btn=QMessageBox::question(this, "提示", "确定要重置吗?", QMessageBox::Yes|QMessageBox::No);

        if(btn==QMessageBox::Yes)
        {
            ui->house_price->setText("0");
            ui->house_area->setText("0");
            ui->ajcs->setText("0");
            ui->ajcs_->setText("0");
            ui->whole_price->setText("0");
            ui->dk_ll->setText("0");
            ui->df_year->setText("0");
            ui->sd_price->setText("0");
            ui->sdll->setText("0");
            ui->gongjijin_dke->setText("0");
            ui->gjj_ll->setText("0");
            ui->output->setText("重置成功！\n");
    }
}
