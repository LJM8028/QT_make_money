#ifndef		_COMMON_H_
#define	_COMMON_H_

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>  
#include<iostream>  
#include<string.h>  
#include <stdlib.h>  
#include <qDebug>

#endif