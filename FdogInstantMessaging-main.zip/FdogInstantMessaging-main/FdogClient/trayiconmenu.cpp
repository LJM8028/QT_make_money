﻿#include "trayiconmenu.h"

TrayIconMenu::TrayIconMenu()
{

}
