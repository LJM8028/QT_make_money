﻿#ifndef TRAYICONMENU_H
#define TRAYICONMENU_H
#include<QMenu>

class TrayIconMenu :public QMenu
{
    Q_OBJECT
public:
    TrayIconMenu();
};

#endif // TRAYICONMENU_H
