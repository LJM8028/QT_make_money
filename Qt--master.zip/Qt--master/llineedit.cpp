#include "llineedit.h"

LLineEdit::LLineEdit(QWidget *parent) : QWidget(parent)
{

}
