#ifndef LLINEEDIT_H
#define LLINEEDIT_H

#include <QWidget>

class LLineEdit : public QWidget
{
    Q_OBJECT
public:
    explicit LLineEdit(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // LLINEEDIT_H
