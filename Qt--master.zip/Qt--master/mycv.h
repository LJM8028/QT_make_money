#ifndef MYCV_H
#define MYCV_H
int color();
int sport();
int face();
#endif // MYCV_H
