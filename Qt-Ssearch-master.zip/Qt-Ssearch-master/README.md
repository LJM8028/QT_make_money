# 基于Qt的文件快速搜索工具（调用everything.dll）
