/********************************************************************************
** Form generated from reading UI file 'moneyfind.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MONEYFIND_H
#define UI_MONEYFIND_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_moneyfind
{
public:
    QLabel *label;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_9;
    QLineEdit *stu_money_banji_lineEdit;
    QLineEdit *stu_money_termlineEdit;
    QLineEdit *stu_money_arrearagelineEdit;
    QLineEdit *stu_money_namelineEdit;
    QLineEdit *stu_money_majorlineEdit;
    QLineEdit *stu_money_feelineEdit;
    QLineEdit *stu_moneyIDineEdit;
    QLabel *label_8;
    QPushButton *stu_money_queryButton;
    QPushButton *stu_money_backButton;

    void setupUi(QWidget *moneyfind)
    {
        if (moneyfind->objectName().isEmpty())
            moneyfind->setObjectName(QStringLiteral("moneyfind"));
        moneyfind->resize(566, 377);
        label = new QLabel(moneyfind);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(230, 30, 54, 12));
        label_3 = new QLabel(moneyfind);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(63, 50, 131, 20));
        label_4 = new QLabel(moneyfind);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(160, 10, 231, 31));
        label_4->setStyleSheet(QStringLiteral("font: 20pt \"Arial\";"));
        label_2 = new QLabel(moneyfind);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 120, 54, 12));
        label_5 = new QLabel(moneyfind);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 170, 54, 12));
        label_6 = new QLabel(moneyfind);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(40, 220, 54, 12));
        label_7 = new QLabel(moneyfind);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(330, 180, 54, 12));
        label_9 = new QLabel(moneyfind);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(330, 90, 54, 12));
        stu_money_banji_lineEdit = new QLineEdit(moneyfind);
        stu_money_banji_lineEdit->setObjectName(QStringLiteral("stu_money_banji_lineEdit"));
        stu_money_banji_lineEdit->setGeometry(QRect(120, 120, 131, 20));
        stu_money_termlineEdit = new QLineEdit(moneyfind);
        stu_money_termlineEdit->setObjectName(QStringLiteral("stu_money_termlineEdit"));
        stu_money_termlineEdit->setGeometry(QRect(120, 170, 131, 20));
        stu_money_arrearagelineEdit = new QLineEdit(moneyfind);
        stu_money_arrearagelineEdit->setObjectName(QStringLiteral("stu_money_arrearagelineEdit"));
        stu_money_arrearagelineEdit->setGeometry(QRect(120, 220, 131, 20));
        stu_money_namelineEdit = new QLineEdit(moneyfind);
        stu_money_namelineEdit->setObjectName(QStringLiteral("stu_money_namelineEdit"));
        stu_money_namelineEdit->setGeometry(QRect(400, 90, 131, 20));
        stu_money_majorlineEdit = new QLineEdit(moneyfind);
        stu_money_majorlineEdit->setObjectName(QStringLiteral("stu_money_majorlineEdit"));
        stu_money_majorlineEdit->setGeometry(QRect(400, 130, 131, 20));
        stu_money_feelineEdit = new QLineEdit(moneyfind);
        stu_money_feelineEdit->setObjectName(QStringLiteral("stu_money_feelineEdit"));
        stu_money_feelineEdit->setGeometry(QRect(400, 180, 131, 20));
        stu_moneyIDineEdit = new QLineEdit(moneyfind);
        stu_moneyIDineEdit->setObjectName(QStringLiteral("stu_moneyIDineEdit"));
        stu_moneyIDineEdit->setGeometry(QRect(220, 50, 113, 20));
        label_8 = new QLabel(moneyfind);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(330, 130, 54, 12));
        stu_money_queryButton = new QPushButton(moneyfind);
        stu_money_queryButton->setObjectName(QStringLiteral("stu_money_queryButton"));
        stu_money_queryButton->setGeometry(QRect(140, 300, 75, 23));
        stu_money_backButton = new QPushButton(moneyfind);
        stu_money_backButton->setObjectName(QStringLiteral("stu_money_backButton"));
        stu_money_backButton->setGeometry(QRect(360, 300, 75, 23));

        retranslateUi(moneyfind);

        QMetaObject::connectSlotsByName(moneyfind);
    } // setupUi

    void retranslateUi(QWidget *moneyfind)
    {
        moneyfind->setWindowTitle(QApplication::translate("moneyfind", "\347\206\212\344\271\211\350\276\2602020141640168", Q_NULLPTR));
        label->setText(QString());
        label_3->setText(QApplication::translate("moneyfind", "\350\257\267\350\276\223\345\205\245\346\211\200\350\246\201\346\237\245\350\257\242\347\232\204\345\255\246\345\217\267\357\274\232", Q_NULLPTR));
        label_4->setText(QApplication::translate("moneyfind", "\345\255\246\347\224\237\347\274\264\350\264\271\344\277\241\346\201\257\347\256\241\347\220\206", Q_NULLPTR));
        label_2->setText(QApplication::translate("moneyfind", "\347\217\255\347\272\247\357\274\232", Q_NULLPTR));
        label_5->setText(QApplication::translate("moneyfind", "\345\255\246\346\234\237\357\274\232", Q_NULLPTR));
        label_6->setText(QApplication::translate("moneyfind", "\346\254\240\350\264\271\346\203\205\345\206\265\357\274\232", Q_NULLPTR));
        label_7->setText(QApplication::translate("moneyfind", "\345\255\246\350\264\271\357\274\232", Q_NULLPTR));
        label_9->setText(QApplication::translate("moneyfind", "\345\247\223\345\220\215\357\274\232", Q_NULLPTR));
        label_8->setText(QApplication::translate("moneyfind", "\344\270\223\344\270\232\357\274\232", Q_NULLPTR));
        stu_money_queryButton->setText(QApplication::translate("moneyfind", "\346\237\245\346\211\276", Q_NULLPTR));
        stu_money_backButton->setText(QApplication::translate("moneyfind", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class moneyfind: public Ui_moneyfind {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MONEYFIND_H
