#include "fileutil.h"
#include <QDebug>
#include <QFile>

const QString studentInfoFileName="E:/workspace/qt_lesson/StudentsMIS/res/studentdata.txt";
const QString userInfoFileName="E:/workspace/qt_lesson/StudentsMIS/res/userinfo.txt";

fileUtil::fileUtil(QObject *parent) : QObject(parent)
{

}

QString fileUtil::readFile(QString fileName)
{
    QString res="";
    if(fileName.isEmpty())
    {
        qDebug()<<"Empty File";
        return NULL;
    }

    QFile *file = new QFile;
    file->setFileName(fileName);
    bool ok = file->open(QIODevice::ReadOnly);
    if(ok)
    {
        QTextStream in(file);
        in.setCodec("UTF-8");
        res=in.readAll();
        qDebug()<<res;
        file->close();
        //delete file;
    }
    else
    {
        qDebug()<<"Read File error!";
        return NULL;
    }
    return res;
}
bool fileUtil::writeFile(QString fileName, QString text)
{
    if(fileName.isEmpty() || text.isEmpty())
    {
        qDebug()<<"Empty File or text";
        return false;
    }
    QFile *file = new QFile;
    file->setFileName(fileName);
    if(file->isOpen())file->close();
    bool ok = file->open(QIODevice::WriteOnly);
    if(ok)
    {
        QTextStream out(file);
        out.setCodec("UTF-8");
        out<<text;
        file->close();
       // delete file;
    }
    else
    {
        qDebug()<<"Save File Error!";
        return false;
    }
    return true;
}

QList<studentData> fileUtil::readStudentData()
{
  QString str0=readFile(studentInfoFileName);
  QList<studentData>* reslist=new QList<studentData>();
  if(!str0.isEmpty())
  {
     QStringList strList0=str0.split("\r\n",QString::SkipEmptyParts);
     if(!strList0.isEmpty() && strList0.length()>0)
     {
         for(int js=0;js<strList0.length();js++){
             QStringList strList1=strList0[js].split(",",QString::SkipEmptyParts);
             if(!strList1.isEmpty() && strList1.length()==5){
                studentData* stu1=new studentData(strList1);
                reslist->append(*stu1);
             }
         }
     }
  }
  return  *reslist;
}

bool fileUtil::writeStudentData(QList<studentData> studentList)
{
   if(!studentList.isEmpty() && studentList.count()>0)
   {
       QString str="";
      for(int js=0;js<studentList.count();js++)
      {
         studentData sd1=studentList[js];
         str+=sd1.getStudent_no()+","+sd1.getStudent_name()+","+sd1.getStudent_sex()
                 +","+sd1.getStudent_age()+","+sd1.getStudent_major()+"\r\n";
      }
      if(str.length()>0)
          writeFile(studentInfoFileName,str);
   }
}

QList<userInfoData> fileUtil::readUserinfoData()
{
    QString str0=readFile(userInfoFileName);
    QList<userInfoData>* reslist=new QList<userInfoData>();
    if(!str0.isEmpty())
    {
       QStringList strList0=str0.split("\r\n",QString::SkipEmptyParts);
       if(!strList0.isEmpty() && strList0.length()>0)
       {
           for(int js=0;js<strList0.length();js++){
               QStringList strList1=strList0[js].split(",",QString::SkipEmptyParts);
               if(!strList1.isEmpty() && strList1.length()==2){
                  userInfoData* user1=new userInfoData(strList1);
                  reslist->append(*user1);
               }
           }
       }
    }
    return  *reslist;
}

bool fileUtil::writeUserinfoData(QList<userInfoData> userList)
{
    if(!userList.isEmpty() && userList.count()>0)
    {
        QString str="";
       for(int js=0;js<userList.count();js++)
       {
          userInfoData user1=userList[js];
          str+=user1.getUsername()+","+user1.getPassword()+"\r\n";
       }
       if(str.length()>0)
           writeFile(userInfoFileName,str);
    }
}
