#include "insertpage.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QMessageBox>
#include "fileutil.h"

insertPage::insertPage(QWidget *parent) : QWidget(parent)
{
    this->_mainWindow=(myMainWindow*)parent;
     //学号、姓名、性别、年龄、专业
    QLabel* titleLabel=new QLabel(this);
    titleLabel->setText("学生信息添加");
    titleLabel->setAlignment(Qt::AlignCenter);
    QPushButton*  insertBtn=new QPushButton(this);
    insertBtn->setText("添加");
    QPushButton*  resetBtn=new QPushButton(this);
    resetBtn->setText("重置");
    QLabel* noLabel=new QLabel(this);
    noLabel->setText("学号：");
    QLabel* nameLabel=new QLabel(this);
    nameLabel->setText("姓名：");
    QLabel* sexLabel=new QLabel(this);
    sexLabel->setText("性别：");
    QLabel* ageLabel=new QLabel(this);
    ageLabel->setText("年龄：");
    QLabel* majorLabel=new QLabel(this);
    majorLabel->setText("专业：");
    noEdit=new QLineEdit(this);
    nameEdit=new QLineEdit(this);
    sexEdit=new QLineEdit(this);
    ageEdit=new QLineEdit(this);
    majorEdit=new QLineEdit(this);

    QGridLayout *gridLayout = new QGridLayout;
    gridLayout->setSpacing(10);   //设置单元间隔
    gridLayout->setMargin(20);    //设置边距
    gridLayout->addWidget(titleLabel,0,0,1,4);
    gridLayout->addWidget(insertBtn,1,0,1,2);
    gridLayout->addWidget(resetBtn,1,2,1,2);
    gridLayout->addWidget(noLabel,2,0,1,1);
    gridLayout->addWidget(noEdit,2,1,1,1);
    gridLayout->addWidget(nameLabel,2,2,1,1);
    gridLayout->addWidget(nameEdit,2,3,1,1);
    gridLayout->addWidget(sexLabel,3,0,1,1);
    gridLayout->addWidget(sexEdit,3,1,1,1);
    gridLayout->addWidget(ageLabel,3,2,1,1);
    gridLayout->addWidget(ageEdit,3,3,1,1);
    gridLayout->addWidget(majorLabel,4,0,1,1);
    gridLayout->addWidget(majorEdit,4,1,1,1);
    this->setLayout(gridLayout);
    this->resize(1000, 300);
    connect(insertBtn,&QPushButton::clicked,this,&insertPage::insertBtnClicked);
    connect(resetBtn,&QPushButton::clicked,this,&insertPage::resetBtnClicked);
}

void insertPage::insertBtnClicked()
{
    if(noEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入学号！");
        return;
    }
    else if(nameEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入姓名！");
        return;
    }
    else if(sexEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入性别！");
        return;
    }
    else if(ageEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入年龄！");
        return;
    }
    else if(majorEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入专业！");
        return;
    }
    QStringList* studentTmp=new QStringList();
    studentTmp->append(noEdit->text());
    studentTmp->append(nameEdit->text());
    studentTmp->append(sexEdit->text());
    studentTmp->append(ageEdit->text());
    studentTmp->append(majorEdit->text());
    studentData* sd0=new studentData(*studentTmp);
    bool res=this->_mainWindow->insertStudentInfo(*sd0);
    if(res)QMessageBox::about(this,"提醒","学生信息添加成功！");
    else QMessageBox::about(this,"提醒","学生信息添加失败！");
}

void insertPage::resetBtnClicked()
{
    noEdit->setText("");
    nameEdit->setText("");
    sexEdit->setText("");
    ageEdit->setText("");
    majorEdit->setText("");
}

