#include "mainwindow.h"
#include "QVBoxLayout"
#include "fileutil.h"


myMainWindow::myMainWindow(QWidget *parent) : QDialog(parent)
{
    QVBoxLayout* vlay=new QVBoxLayout(this);
    tabWidget = new QTabWidget(this);
    //新建第一个页面的部件
    selectPageWidget=new selectPage(this);
    tabWidget->addTab(selectPageWidget, "查询信息");
    //新建第二个页面的部件
    insertPageWidget=new insertPage(this);
    tabWidget->addTab(insertPageWidget, "新增信息");
    //新建第三个页面的部件
    updatePageWidget=new updatePage(this);
    tabWidget->addTab(updatePageWidget, "修改信息");
    //新建第四个页面的部件
    deletePageWidget=new deletePage(this);
    tabWidget->addTab(deletePageWidget, "删除信息");
    //新建第五个页面的部件
    modifyUserInfoWidget=new modifyUserInfo(this);
    tabWidget->addTab(modifyUserInfoWidget, "用户信息");
    vlay->addWidget(tabWidget);
    this->setLayout(vlay);
   // tabWidget->setGeometry(0,0,1000,500);

    connect(tabWidget,&QTabWidget::currentChanged,selectPageWidget,&selectPage::tabCurrentChanged);
    connect(tabWidget,&QTabWidget::currentChanged,deletePageWidget,&deletePage::tabCurrentChanged);
    connect(tabWidget,&QTabWidget::currentChanged,updatePageWidget,&updatePage::tabCurrentChanged);

    this->setWindowTitle("学生信息管理系统");
    this->resize(1000, 300);
}

studentData myMainWindow::getStudentInfoByName(QString name1)
{
    studentData res;
    if(!name1.isEmpty() && name1.length()>0){
       getStudentList();
       if(!_studentDataList.isEmpty() && _studentDataList.count()>0)
       {
           for (int js=0;js<_studentDataList.count();js++) {
             studentData sd0=_studentDataList[js];
             if(sd0.getStudent_name()==name1)
             {
                 res=sd0;
                 break;
             }
           }
       }
    }
    return res;
}

bool myMainWindow::insertStudentInfo(studentData sd1)
{
    bool res=false;
    if(!sd1.getStudent_no().isEmpty()){
       getStudentList();
       int index=-1;
       for(int js=0;js<_studentDataList.count();js++){
           if(sd1.getStudent_no()==_studentDataList[js].getStudent_no())
           {
               index=js; //存在该学号的学生
               break;
           }
       }
       if(index<0){
         _studentDataList.append(sd1);
       }
       else
       {
          _studentDataList[index]=sd1;
       }
      fileUtil* fu1=new fileUtil(this);
      fu1->writeStudentData(_studentDataList);
       res=true;
    }
    return res;
}

bool myMainWindow::deleteStudentInfo(QString no1)
{
    bool res=false;
    if(!no1.isEmpty())
    {
        getStudentList();
        int index=-1;
        for(int js=0;js<_studentDataList.count();js++){
            if(no1==_studentDataList[js].getStudent_no())
            {
                index=js; //存在该学号的学生
                break;
            }
        }
        if(index>=0){
          _studentDataList.removeAt(index);
        }
       fileUtil* fu1=new fileUtil(this);
       fu1->writeStudentData(_studentDataList);
       res=true;
    }
    return res;
}


QList<studentData> myMainWindow::getStudentList()
{
     fileUtil* fu1=new fileUtil(this);
    _studentDataList= fu1->readStudentData();
    return _studentDataList;
}
