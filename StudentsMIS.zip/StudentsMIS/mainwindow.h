#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QTabWidget>
#include "selectpage.h"
#include "insertpage.h"
#include "updatepage.h"
#include "deletepage.h"
#include "modifyuserinfo.h"
#include "studentdata.h"

class selectPage;
class insertPage;
class updatePage;
class deletePage;
class modifyUserInfo;
class myMainWindow : public QDialog
{
    Q_OBJECT
    QTabWidget *tabWidget;
public:
    explicit myMainWindow(QWidget *parent = nullptr);
    QList<studentData> getStudentList();
    studentData getStudentInfoByName(QString name1); //查询
    bool insertStudentInfo(studentData sd1);  //添加或新增： no唯一
    bool deleteStudentInfo(QString no1);

signals:

private:
    selectPage* selectPageWidget;
    insertPage* insertPageWidget;
    updatePage* updatePageWidget;
    deletePage* deletePageWidget;
    modifyUserInfo* modifyUserInfoWidget;
    QList<studentData> _studentDataList;

};

#endif // MAINWINDOW_H
