#include "studentdata.h"
#include <QString>
using namespace std;

studentData::studentData()
{

}

studentData::studentData(QStringList studentTmp)
{
    if(!studentTmp.isEmpty() && studentTmp.length()==5){
       setStudent_no(studentTmp[0]);
       setStudent_name(studentTmp[1]);
       setStudent_sex(studentTmp[2]);
       setStudent_age(studentTmp[3]);
       setStudent_major(studentTmp[4]);
    }
}

QString studentData::getStudent_no() const
{
    return student_no;
}

void studentData::setStudent_no(QString value)
{
    student_no = QString(value);
}

QString studentData::getStudent_name() const
{
    return student_name;
}

void studentData::setStudent_name(QString value)
{
    student_name = QString(value);
}

QString studentData::getStudent_sex() const
{
    return student_sex;
}

void studentData::setStudent_sex(QString value)
{
    student_sex = QString(value);
}

QString studentData::getStudent_age() const
{
    return student_age;
}

void studentData::setStudent_age(QString value)
{
    student_age = QString(value);
}

QString studentData::getStudent_major() const
{
    return student_major;
}

void studentData::setStudent_major(QString value)
{
    student_major = QString(value);
}
