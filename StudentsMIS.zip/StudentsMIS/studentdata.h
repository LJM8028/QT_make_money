#ifndef STUDENTDATA_H
#define STUDENTDATA_H
#include <QString>
#include <QStringList>

class studentData
{
public:
    studentData();
    studentData(QStringList studentTmp);
    QString getStudent_no() const;
    void setStudent_no(QString value);

    QString getStudent_name() const;
    void setStudent_name(QString value);

    QString getStudent_sex() const;
    void setStudent_sex(QString value);

    QString getStudent_age() const;
    void setStudent_age(QString value);

    QString getStudent_major() const;
    void setStudent_major(QString value);

private:
    //学号、姓名、性别、年龄、专业
    QString student_no;
    QString student_name;
    QString student_sex;
    QString student_age;
    QString student_major;
};

#endif // STUDENTDATA_H
