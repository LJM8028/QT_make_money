#include "updatepage.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QMessageBox>
#include "fileutil.h"

updatePage::updatePage(QWidget *parent) : QWidget(parent)
{
    this->_mainWindow=(myMainWindow*)parent;
     //学号、姓名、性别、年龄、专业
    QLabel* titleLabel=new QLabel(this);
    titleLabel->setText("学生信息修改");
    titleLabel->setAlignment(Qt::AlignCenter);
    comBox=new QComboBox(this);
    comboAddData();
    QPushButton* updateBtn=new QPushButton(this);
    updateBtn->setText("保存");
    QLabel* noLabel=new QLabel(this);
    noLabel->setText("学号：");
    QLabel* nameLabel=new QLabel(this);
    nameLabel->setText("姓名：");
    QLabel* sexLabel=new QLabel(this);
    sexLabel->setText("性别：");
    QLabel* ageLabel=new QLabel(this);
    ageLabel->setText("年龄：");
    QLabel* majorLabel=new QLabel(this);
    majorLabel->setText("专业：");
    noEdit=new QLineEdit(this);
    nameEdit=new QLineEdit(this);
    sexEdit=new QLineEdit(this);
    ageEdit=new QLineEdit(this);
    majorEdit=new QLineEdit(this);
    noEdit->setEnabled(false);

    QGridLayout *gridLayout = new QGridLayout;
    gridLayout->setSpacing(10);   //设置单元间隔
    gridLayout->setMargin(20);    //设置边距
    gridLayout->addWidget(titleLabel,0,0,1,4);
    gridLayout->addWidget(comBox,1,0,1,2);

    gridLayout->addWidget(updateBtn,1,3,1,1);
    gridLayout->addWidget(noLabel,2,0,1,1);
    gridLayout->addWidget(noEdit,2,1,1,1);
    gridLayout->addWidget(nameLabel,2,2,1,1);
    gridLayout->addWidget(nameEdit,2,3,1,1);
    gridLayout->addWidget(sexLabel,3,0,1,1);
    gridLayout->addWidget(sexEdit,3,1,1,1);
    gridLayout->addWidget(ageLabel,3,2,1,1);
    gridLayout->addWidget(ageEdit,3,3,1,1);
    gridLayout->addWidget(majorLabel,4,0,1,1);
    gridLayout->addWidget(majorEdit,4,1,1,1);
    this->setLayout(gridLayout);
    this->resize(1000, 300);
    currentIndexChanged(0);
    connect(updateBtn,&QPushButton::clicked,this,&updatePage::updateBtnClicked);
    connect(comBox,SIGNAL(currentIndexChanged(int)),this,SLOT(currentIndexChanged(int)));


}

void updatePage::tabCurrentChanged(int index)
{
    comboAddData();
    currentIndexChanged(0);
}

void updatePage::currentIndexChanged(int index)
{
    qDebug()<<comBox->currentText();
    studentData sd0=this->_mainWindow->getStudentInfoByName(comBox->currentText());
    //if(sd0!=NULL)
    //{
       noEdit->setText(sd0.getStudent_no());
       nameEdit->setText(sd0.getStudent_name());
       sexEdit->setText(sd0.getStudent_sex());
       ageEdit->setText(sd0.getStudent_age());
       majorEdit->setText(sd0.getStudent_major());
       //}
}

void updatePage::updateBtnClicked()
{
    if(noEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入学号！");
        return;
    }
    else if(nameEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入姓名！");
        return;
    }
    else if(sexEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入性别！");
        return;
    }
    else if(ageEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入年龄！");
        return;
    }
    else if(majorEdit->text().isEmpty())
    {
        QMessageBox::about(this,"提醒","请输入专业！");
        return;
    }
    QStringList* studentTmp=new QStringList();
    studentTmp->append(noEdit->text());
    studentTmp->append(nameEdit->text());
    studentTmp->append(sexEdit->text());
    studentTmp->append(ageEdit->text());
    studentTmp->append(majorEdit->text());
    studentData* sd0=new studentData(*studentTmp);
    bool res=this->_mainWindow->insertStudentInfo(*sd0);
    if(res)
    {
        QMessageBox::about(this,"提醒","学生信息修改成功！");
        comboAddData();
        currentIndexChanged(0);
    }
    else QMessageBox::about(this,"提醒","学生信息修改失败！");


}

void updatePage::comboAddData()
{
    fileUtil* fu1=new fileUtil(this);
    //fu1->writeFile("test.txt",ss);
    QList<studentData> res= fu1->readStudentData();
    if(!res.isEmpty() && res.count()>0)
    {
        comBox->clear();
        for(int js=0;js<res.count();js++)
        {
            studentData tmp=res[js];
            comBox->addItem(tmp.getStudent_name(),tmp.getStudent_no());

        }
    }
}
