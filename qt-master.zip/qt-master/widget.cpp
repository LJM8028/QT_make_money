#include "widget.h"
#include "ui_widget.h"
#include <QSize>
#include <QComboBox>
#include <QSerialPortInfo>
#include <QStringList>
#include <QSerialPort>
#include <QDebug>
#include <QMessageBox>
#include <QString>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //主界面
    this->setFixedSize(QSize(560, 480));
    //接收框
    ui->TextReceive->setReadOnly(true);

    //广告框
    //ui->groupBox->setMaximumSize(QSize(300, 100));

    //box
    ui->Box_boundrate->addItem("4800");
    ui->Box_boundrate->addItem("9600");
    ui->Box_boundrate->addItem("115200");
    ui->Box_boundrate->setCurrentIndex(1);

    ui->Box_data->addItem("8");
    ui->Box_data->addItem("7");
    ui->Box_data->addItem("6");
    ui->Box_data->addItem("5");
    ui->Box_data->setCurrentIndex(0);

    ui->Box_stopbit->addItem("1");
    ui->Box_stopbit->addItem("1.5");
    ui->Box_stopbit->addItem("2");
    ui->Box_stopbit->setCurrentIndex(0);

    ui->Box_chack->addItem("NULL");
    ui->Box_chack->setCurrentIndex(0);

    ui->Box_stream->addItem("NULL");
    ui->Box_stream->setCurrentIndex(0);

    //骚操作要开始了
//    QStringList serialNamePort;

    //堆区申请变量并加入对象树
    serialport = new QSerialPort(this);

    //参数是一个串口类的引用，自动搜索串口，并用留的方式保存到字符串列表里
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        serialNamePort<<info.portName();
    }

    ui->Box_serial->addItems(serialNamePort);
    this->startTimer(100);

    connect(ui->Button_closeSerial, &QPushButton::clicked,this,&Widget::Button_close_clicked);
    connect(serialport, SIGNAL(readyRead()), this, SLOT(serial_port_read_ready()));

}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_Button_openSerial_clicked()
{
    //枚举体
    QSerialPort::BaudRate baudRate;
    QSerialPort::DataBits dataBits;
    QSerialPort::StopBits stopBits;
    QSerialPort::Parity parity;

//    qDebug() << ui->Box_boundrate->currentText();
    if(ui->Box_boundrate->currentText() == "4800")
    {
        baudRate = QSerialPort::Baud4800;
    }else if(ui->Box_boundrate->currentText() == "9600")
    {
        baudRate = QSerialPort::Baud9600;
    }else if(ui->Box_boundrate->currentText() == "115200")
    {
        baudRate = QSerialPort::Baud115200;
    }else
    {
        baudRate = QSerialPort::UnknownBaud;
    }

    if(ui->Box_stopbit->currentText() == "1")
    {
        stopBits = QSerialPort::OneStop;
    }else if(ui->Box_stopbit->currentText() == "1.5")
    {
        stopBits = QSerialPort::OneAndHalfStop;
    }else if(ui->Box_stopbit->currentText() == "2")
    {
        stopBits = QSerialPort::TwoStop;
    }else
    {
        stopBits = QSerialPort::UnknownStopBits;
    }

    if(ui->Box_data->currentText() == "5")
    {
        dataBits = QSerialPort::Data5;
    }else if(ui->Box_data->currentText() == "6")
    {
        dataBits = QSerialPort::Data6;
    }else if(ui->Box_data->currentText() == "7")
    {
        dataBits = QSerialPort::Data7;
    }else if(ui->Box_data->currentText() == "8")
    {
        dataBits = QSerialPort::Data8;
    }else
    {
        dataBits = QSerialPort::UnknownDataBits;
    }

    if (ui->Box_chack->currentText() == "NULL")
    {
        parity = QSerialPort::NoParity;
    }else
    {
        parity = QSerialPort::UnknownParity;
    }

    //设置port这里没懂
    serialport->setPortName(ui->Box_serial->currentText());
//    serialport->setPort(info);
    serialport->setBaudRate(baudRate);
    serialport->setDataBits(dataBits);
    serialport->setStopBits(stopBits);
    serialport->setParity(parity);

    if(serialport->open(QIODevice::ReadWrite) == true)
    {
        QMessageBox::information(this,"提示","成功打开串口");
    }else
    {
        QMessageBox::critical(this,"警告","打开串口失败");
    }
}



void Widget::Button_close_clicked()
{
    serialport->close();
//    if(true)
//    {
//        QMessageBox::information(this,"提示","成功关闭串口");
//    }else
//    {
//        QMessageBox::critical(this,"警告","关闭串口失败");
//    }
}

void Widget::serial_port_read_ready()
{
    QString buf;
    buf = QString(serialport->readAll());
    ui->TextReceive->appendPlainText(buf);
//    qDebug() << buf;
//    qDebug() << "hello";
}

void Widget::on_Button_send_clicked()
{
    serialport->write(ui->Edit_send->text().toLocal8Bit().data());

}

void Widget::on_Button_clear_clicked()
{
    ui->TextReceive->clear();
}

void Widget::timerEvent(QTimerEvent* e)
{
    ui->Box_serial->clear();
    serialNamePort.clear();
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        serialNamePort<<info.portName();
    }
    ui->Box_serial->addItems(serialNamePort);
}
