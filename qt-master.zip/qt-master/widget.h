#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    //结构体指针
    QSerialPort *serialport;
    QStringList serialNamePort;

    virtual void timerEvent(QTimerEvent* e);

private slots:
    void on_Button_openSerial_clicked();
    void Button_close_clicked();
    void serial_port_read_ready();

    void on_Button_send_clicked();

    void on_Button_clear_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
