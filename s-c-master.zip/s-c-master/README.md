# s-c
7z为可执行文件\
一个简单的基于Qt\C++的多线程Server和Client\
使用Tcp长连接+心跳确定用户在线状态\
使用Udp经Server转发实现用户间的通信
